from django import forms

class UploadFileForm(forms.Form):
    file = forms.CharField(widget=forms.Textarea(attrs={'width':"100%", 'cols' : "80", 'rows': "20", }))
