#!/usr/bin/python -tt
from py2neo import Graph
from nltk.corpus import wordnet
import goslate
def missing():
    MissConcepts=[]
    MissAttributes=[]
    MissRelations=[]
    ### get all nodes labels...
    def get_node():
        user_name='neo4j'
        password='jihenepcd'
        url="http://"+user_name+":"+password+"@localhost:7474/db/data/"
        graph = Graph(url)
        nodes=[]
        for n in graph.run("START z=node(*) RETURN distinct labels(z)"):
            # //do something with node here
            node=list(n)
            for el in node:
                for ell in el:
                    nodes.append(el)
        return nodes
    ### get all attributs..
    def get_attributs(n):
        user_name='neo4j'
        password='jihenepcd'
        url="http://"+user_name+":"+password+"@localhost:7474/db/data/"
        graph = Graph(url)
        attributs=[]
        attributs=[]
        for a in graph.run("Match (n:"+n+") RETURN distinct keys(n)"):
            # //do something with node here
            att=list(a)
            for el in att:
                for ell in el:
                    attributs.append(ell)
        return(attributs)

    ### get all relationships..
    def get_relationships():
        user_name='neo4j'
        password='jihenepcd'
        url="http://"+user_name+":"+password+"@localhost:7474/db/data/"
        graph = Graph(url)
        relationships=[]
        q='MATCH (n)-[r]-(m) RETURN distinct labels(n),type(r),labels(m);'
        for el in graph.run(q):
            relationships.append(list(el))
        return relationships
    ### relationships
    relationships=get_relationships()
    print(relationships)
    with open("/home/jihene/Bureau/queries.txt", "r") as myfile:
        for Queries in myfile:
            Q=Queries
            print(Q)
            Q=Q.replace(','," ")
            Q=Q.split()
            pos2=0
            pos1=0
            pos3=0
            for i in range(0,len(Q)-1):
                if 'from' in Q[i]:
                    pos1=i
                if 'where' in Q[i]:
                    pos2=i
                if 'select' in Q[i]:
                    pos3=i
                if pos2==0:
                    pos2=len(Q)
            print(pos1)
            print(pos2)
            print(pos3)
            nb_concepts=abs(pos2-pos1-1)
            concepts=[]
            attributs=[]
            conditions=[]
            # la liste de tous les concepts de la requete Q
            for i in range(pos1+1,pos2):
                concepts.append(Q[i])
            # la liste de tous les attributs de la requete Q
            print(concepts)
            for i in range(pos3+1,pos1):
                attributs.append(Q[i])
            print(attributs)
            # la liste de tous les conditions de la requete Q
            for i in range(pos2+1,len(Q)):
                Q[i]=Q[i].replace("="," ")
                conditions.append(Q[i])
            print(conditions)
            #initialiser la liste MissConcepts a partir de la requete Q
            for i in range(0,len(concepts)):
                if "?" in concepts[i]:
                    concepts[i]=concepts[i].replace("?","")
                    MissConcepts.append(concepts[i])
            #initialiser la liste MissAttributs a partir de la requete Q
            print(MissConcepts)
            for i in range(0,len(attributs)):
                if "?" in attributs[i]:
                    missAtt=[]
                    attributs[i]=attributs[i].replace('?',"")
                    missAtt.append(attributs[i])
                    for i in range(0,len(concepts)):
                        missAtt.append(concepts[i])
                    missAtt.append("uncertain")
                    MissAttributes.append(missAtt)
            print(MissAttributes)
            if nb_concepts == 1:
                concept=concepts[0]
                nodes=get_node()
                print(nodes)
                if any(concept in s for s in nodes)==True:
                    attributs_node=get_attributs(concept)
                    print(attributs_node)
                    for i in range(0,len(attributs)):
                        if attributs[i] not in attributs_node:
                            liste_att=[]
                            att=attributs[i]
                            liste_att.append(att)
                            liste_att.append(concept)
                            liste_att.append("certain")
                            MissAttributes.append(liste_att)
                            #print(liste_att)
                elif any(concept in s for s in MissConcepts)==True:
                    for att in attributs:
                        liste_att=[]
                        liste_att.append(att)
                        liste_att.append(concept)
                        liste_att.append("uncertain")
                        if liste_att in MissAttributes:
                            indice=MissAttributes.index(liste_att)
                            MissAttributes[indice][2]="certain"
                        else:
                            liste_att[2]="certain"
                            MissAttributes.append(liste_att)
                    print(MissAttributes)
                else:
                    MissConcepts.append(concept)
                    for att in attributs:
                        liste_att=[]
                        liste_att.append(att)
                        liste_att.append(concept)
                        liste_att.append("uncertain")
                        if liste_att in MissAttributes:
                            indice=MissAttributes.index(liste_att)
                            MissAttributes[indice][2]="certain"
                        else:
                            liste_att[2]="certain"
                            MissAttributes.append(liste_att)
                    print(MissAttributes)
                    print(MissConcepts)
            else:
                for concept in concepts:
                    if concept not in MissConcepts:
                        MissConcepts.append(concept)
                print(MissConcepts)
            attribut_concept=[]
            #get related attribute-concept pairs < att, c > in cond
            for c in conditions:
                cond=c.split()
                for i in cond:
                    if "." in i:
                        att_concept=i
                        att_concept=att_concept.replace("."," ")
                        att_concept=att_concept.split()
                        attribut_concept.append(att_concept)
                print(attribut_concept)
                for att_cpt in attribut_concept:
                        missAtt=False
                        #c is not missing from G S and att is missing
                        if att_cpt[0] not in MissConcepts:
                            #print(att_cpt[0])
                            for att in MissAttributes:
                                if att_cpt[1] in att:
                                    missAtt=True
                            if missAtt == True:
                                liste_att=[]
                                liste_att.append(att_cpt[1])
                                liste_att.append(att_cpt[0])
                                liste_att.append("certain")
                                MissAttributes.append(liste_att)
                        #c was defined as a missing concept however att was not defined as a missing attribute related to c
                        else:
                            if  att_cpt[0] in MissConcepts:
                                for att in MissAttributes:
                                    if (att_cpt[0] not in att) and (att_cpt[1] not in att[1]):
                                        missAtt=True
                                if missAtt == True:
                                    liste_att=[]
                                    liste_att.append(att_cpt[1])
                                    liste_att.append(att_cpt[0])
                                    liste_att.append("certain")
                                    MissAttributes.append(liste_att)
                MissRelations=[]
                for i in range (0,len(attribut_concept),2):
                    print(i)
                    MissR=True
                    print(attribut_concept[i][0])
                    print(attribut_concept[i+1][0])
                    for relation in relationships:
                        #print(relation)
                        if (attribut_concept[i][0] in relation[0]) and (attribut_concept[i+1][0] in relation[2]):
                            MissR=False
                    if MissR == True:
                        edge=[]
                        edge.append(attribut_concept[i][0])
                        edge.append(attribut_concept[i+1][0])
                        edge.append(attribut_concept[i][1])
                        MissRelations.append(edge)
                print(MissRelations)
            """
            for c in concepts:
                attribut_node=get_attributs(c)
                for att in attributs:
                    Miss_att=[]
                    Miss_att.append(att)
                    Miss_att.append(c)
                    Miss_att.append("certain")
                    if (att not in attribut_node) and (Miss_att not in MissAttributes):
                        concept=[]
                        for c in concepts:
                            text=att
                            print(text)
                            gs = goslate.Goslate()
                            a=gs.translate(text,'en')
                            print(a)
                            text2=c
                            gs = goslate.Goslate()
                            c1=gs.translate(text2,'en')
                            c1=c1+".n.01"
                            print(c1)
                            w1 = wordnet.synset(a)
                            w2 = wordnet.synset(c1)
                            score=w1.wup_similarity(w2)
                            if score > 0.5 :
                                concept.append(c)
                        Miss_att=[]
                        Miss_att.append(att)
                        Miss_att.append(concept)
                        Miss_att.append("uncertain")
                        MissAttributes.append(Miss_att)
                        """
        listeR=[]
        for missR in MissRelations:
            listeR.append(":".join(missR))
        chnR=",".join(set(listeR))
        listeA=[]
        for missA in MissAttributes:
            listeA.append(missA[0])
        chnA= ",".join(set(listeA))
        chnC= ",".join(MissConcepts)
        All="Missing Concepts : "+chnC+","+chnA+","+" Missing Relation : "+chnR
        print(All)
        return All
