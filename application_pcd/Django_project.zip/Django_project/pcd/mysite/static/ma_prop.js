// No images or JS were harmed in the making of this pen
