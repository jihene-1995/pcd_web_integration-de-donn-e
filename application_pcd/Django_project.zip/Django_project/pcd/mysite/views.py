from django.shortcuts import render
from django.conf import settings
from django.core.files.storage import FileSystemStorage
import os,shutil

from django.views.generic import TemplateView, FormView
from django.contrib import messages
from django.shortcuts import render
from .forms import UploadFileForm
from .missing import missing
from django.contrib.auth.models import User

class Save(FormView):
    template_name = "requete.html"
    form_class = UploadFileForm

    def post(self, request, *args, **kwargs):
        form = self.form_class(request.POST)
        if form.is_valid():
            print (form.cleaned_data['file'])
            with open("/home/jihene/Bureau/queries.txt", "w") as myfile:
                myfile.write(form.cleaned_data['file'])
            test=verifyQuery()
            if test=="true":
                MissInfo=missing()
                messages.success(request, 'Form submission successful')
                messages.success(request, MissInfo)
            else:
                messages.success(request, 'Error,the query syntax is incorrect')
            return render(request, self.template_name, {'form': form})
        else:
            return self.form_invalid(form)


    def get(self, request, *args, **kwargs):
        form = self.form_class()
        return render(request, self.template_name, {'form': form})

def verifyQuery():
	with open("/home/jihene/Bureau/queries.txt", "r") as myfile:
		for line in myfile:
			phrase=line.split()
			print(phrase)
			if ("select" in phrase) and ("from" in phrase):
				i=phrase.index("select")
				j=phrase.index("from")
				if (i==0) and (phrase[i+1]!="from") and (j!=0) and (j!=1):
					if ("where" in phrase):
						k=phrase.index("where")
						if(k!=0)and(k!=1)and(k!=2)and(k!=3):
							ok="true"
					else:
						ok="true"
			else:
				ok="false"
		return ok


def simple_upload(request):
    if request.method == 'POST' and request.FILES['myfile']:
        user = User.objects.get(username=request.user.username)
        print(str(user))
        repertoire="//home/jihene/Bureau/Django_project/pcd/media/"+str(user)
        if not os.path.exists(repertoire):
            os.makedirs(repertoire)
        myfile = request.FILES['myfile']
        fs = FileSystemStorage()
        filename = fs.save(myfile.name, myfile)
        shutil.move("//home/jihene/Bureau/Django_project/pcd/media/"+filename,repertoire+"/"+filename)
    return render(request, 'import.html')
